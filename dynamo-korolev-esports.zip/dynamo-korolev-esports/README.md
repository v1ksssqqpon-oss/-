# Динамо Королёв — Киберспортивная платформа

Профессиональная платформа для организации турниров, ведения статистики и развития киберспортивного сообщества.

## Стек

- Next.js 14 (App Router)
- React 18 + TypeScript
- Tailwind CSS
- Prisma ORM + PostgreSQL
- NextAuth.js
- Framer Motion

## Быстрый старт

```bash
npm install
cp .env.example .env
# Настрой DATABASE_URL в .env
npx prisma generate
npx prisma migrate dev --name init
npx prisma db seed
npm run dev
```

## Деплой на Vercel

1. Залей на GitHub
2. Импортируй в [vercel.com](https://vercel.com)
3. Build Command: `prisma generate && next build`
4. Добавь env vars: `DATABASE_URL`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL`
5. После деплоя: `npx prisma migrate deploy` + `npx prisma db seed`

## Тестовые данные

- Админ: `admin@dynamokorolev.ru` / `admin123`
- Игроки: `ivan@example.com` / `password123`
