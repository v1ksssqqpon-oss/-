import { getServerSession } from "next-auth/next";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Separator } from "@/components/ui/Separator";
import Link from "next/link";
import {
  Trophy, Users, Newspaper, BarChart3, Shield,
  Settings, Image, Calendar, Bell,
} from "lucide-react";

export default async function AdminPage() {
  const session = await getServerSession();
  if (!session?.user?.email) redirect("/login");

  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!user || !["ADMIN", "SUPERADMIN", "ORGANIZER", "MODERATOR"].includes(user.role)) {
    redirect("/");
  }

  const stats = {
    tournaments: await prisma.tournament.count(),
    players: await prisma.player.count(),
    users: await prisma.user.count(),
    news: await prisma.news.count(),
    matches: await prisma.match.count(),
  };

  const adminCards = [
    { title: "Турниры", value: stats.tournaments, icon: Trophy, href: "/admin/tournaments", color: "text-dynamo-500" },
    { title: "Игроки", value: stats.players, icon: Users, href: "/admin/players", color: "text-emerald-500" },
    { title: "Пользователи", value: stats.users, icon: Shield, href: "/admin/users", color: "text-amber-500" },
    { title: "Новости", value: stats.news, icon: Newspaper, href: "/admin/news", color: "text-purple-500" },
    { title: "Матчи", value: stats.matches, icon: BarChart3, href: "/admin/matches", color: "text-red-500" },
    { title: "Галерея", value: 0, icon: Image, href: "/admin/gallery", color: "text-pink-500" },
    { title: "Расписание", value: 0, icon: Calendar, href: "/admin/schedule", color: "text-cyan-500" },
    { title: "Уведомления", value: 0, icon: Bell, href: "/admin/notifications", color: "text-orange-500" },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Админ-панель</h1>
          <p className="mt-1 text-muted-foreground">Управление платформой</p>
        </div>
        <Badge className="bg-dynamo-600">{user.role}</Badge>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {adminCards.map((card) => (
          <Link key={card.title} href={card.href}>
            <Card className="cursor-pointer p-4 transition-all hover:border-dynamo-500/50 hover:shadow-md">
              <div className="flex items-center justify-between">
                <card.icon className={`h-8 w-8 ${card.color}`} />
                <span className="text-2xl font-bold">{card.value}</span>
              </div>
              <p className="mt-2 text-sm font-medium">{card.title}</p>
            </Card>
          </Link>
        ))}
      </div>

      <Separator className="my-8" />

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Быстрые действия
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <Button className="bg-dynamo-600 hover:bg-dynamo-700">+ Создать турнир</Button>
          <Button variant="outline">+ Добавить новость</Button>
          <Button variant="outline">+ Добавить игрока</Button>
          <Button variant="outline">Экспорт данных</Button>
        </CardContent>
      </Card>
    </div>
  );
}
