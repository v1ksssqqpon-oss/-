import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const limit = parseInt(searchParams.get("limit") || "50");
  const orderBy = searchParams.get("orderBy") || "rating";

  const players = await prisma.player.findMany({
    orderBy: { [orderBy]: "desc" },
    take: limit,
  });

  return NextResponse.json(players);
}
