import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");
  const discipline = searchParams.get("discipline");
  const limit = parseInt(searchParams.get("limit") || "50");

  const where: any = {};
  if (status) where.status = status;
  if (discipline) where.discipline = discipline;

  const tournaments = await prisma.tournament.findMany({
    where,
    orderBy: { date: "desc" },
    take: limit,
    include: {
      _count: { select: { registrations: true } },
    },
  });

  return NextResponse.json(tournaments);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const tournament = await prisma.tournament.create({
      data: {
        ...body,
        slug: body.slug || body.name.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""),
      },
    });
    return NextResponse.json(tournament, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: "Failed to create tournament" }, { status: 500 });
  }
}
