import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Calendar, ChevronLeft } from "lucide-react";
import Link from "next/link";

export default async function NewsDetailPage({ params }: { params: { slug: string } }) {
  const item = await prisma.news.findUnique({ where: { slug: params.slug } });
  if (!item) notFound();

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
      <Link href="/news" className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Все новости
      </Link>
      {item.category && <Badge className="mb-3">{item.category}</Badge>}
      <h1 className="text-3xl font-bold tracking-tight">{item.title}</h1>
      <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
        <Calendar className="h-4 w-4" />
        {item.publishedAt ? new Date(item.publishedAt).toLocaleDateString("ru-RU") : ""}
      </div>
      <Card className="mt-6">
        <CardContent className="p-6">
          <div className="prose dark:prose-invert max-w-none whitespace-pre-wrap">
            {item.content}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
