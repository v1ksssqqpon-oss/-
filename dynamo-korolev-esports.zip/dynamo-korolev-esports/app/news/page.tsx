import { prisma } from "@/lib/prisma";
import { NewsCard } from "@/components/home/NewsCard";
import { Card } from "@/components/ui/Card";
import { Newspaper } from "lucide-react";

export default async function NewsPage() {
  const news = await prisma.news.findMany({
    where: { published: true },
    orderBy: [{ pinned: "desc" }, { publishedAt: "desc" }],
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold tracking-tight">Новости</h1>
      <p className="mt-2 text-muted-foreground">Все новости сообщества</p>
      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {news.length > 0 ? (
          news.map((n) => <NewsCard key={n.id} news={n} />)
        ) : (
          <Card className="p-8 text-center col-span-full">
            <Newspaper className="mx-auto h-10 w-10 text-muted-foreground/40" />
            <p className="mt-3 text-muted-foreground">Новости скоро появятся</p>
          </Card>
        )}
      </div>
    </div>
  );
}
