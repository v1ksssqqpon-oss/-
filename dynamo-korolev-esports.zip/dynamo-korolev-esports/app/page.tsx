import { prisma } from "@/lib/prisma";
import { HeroBanner } from "@/components/home/HeroBanner";
import { TournamentCard } from "@/components/home/TournamentCard";
import { Leaderboard } from "@/components/home/Leaderboard";
import { NewsCard } from "@/components/home/NewsCard";
import { PartnerLogos } from "@/components/home/PartnerLogos";
import { Button } from "@/components/ui/Button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar";
import { Separator } from "@/components/ui/Separator";
import Link from "next/link";
import {
  Trophy,
  Users,
  Calendar,
  Newspaper,
  BarChart3,
  MessageCircle,
  Zap,
  ChevronRight,
  Medal,
  Star,
} from "lucide-react";

async function getHomeData() {
  const featuredTournament = await prisma.tournament.findFirst({
    where: { featured: true },
    orderBy: { date: "asc" },
    include: { _count: { select: { registrations: true } } },
  });

  const upcomingTournaments = await prisma.tournament.findMany({
    where: { status: { in: ["UPCOMING", "REGISTRATION_OPEN"] } },
    orderBy: { date: "asc" },
    take: 3,
    include: { _count: { select: { registrations: true } } },
  });

  const latestNews = await prisma.news.findMany({
    where: { published: true },
    orderBy: [{ pinned: "desc" }, { publishedAt: "desc" }],
    take: 3,
  });

  const topPlayers = await prisma.player.findMany({
    orderBy: { rating: "desc" },
    take: 10,
  });

  const latestWinners = await prisma.player.findMany({
    where: { wins: { gt: 0 } },
    orderBy: { updatedAt: "desc" },
    take: 3,
  });

  const stats = {
    totalTournaments: await prisma.tournament.count(),
    totalPlayers: await prisma.player.count(),
    totalMatches: await prisma.match.count(),
    totalPrize: await prisma.player.aggregate({ _sum: { totalPrize: true } }),
  };

  return {
    featuredTournament,
    upcomingTournaments,
    latestNews,
    topPlayers,
    latestWinners,
    stats,
  };
}

export default async function HomePage() {
  const data = await getHomeData();

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <HeroBanner
        tournament={
          data.featuredTournament
            ? {
                name: data.featuredTournament.name,
                discipline: data.featuredTournament.discipline,
                date: data.featuredTournament.date.toISOString(),
                location: data.featuredTournament.location || undefined,
                maxParticipants: data.featuredTournament.maxParticipants,
                prizePool: data.featuredTournament.prizePool,
                slug: data.featuredTournament.slug,
              }
            : null
        }
      />

      {/* Stats bar */}
      <section className="border-b border-border/40 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {[
              {
                icon: Trophy,
                value: data.stats.totalTournaments,
                label: "Турниров",
              },
              {
                icon: Users,
                value: data.stats.totalPlayers,
                label: "Игроков",
              },
              {
                icon: Zap,
                value: data.stats.totalMatches,
                label: "Матчей",
              },
              {
                icon: Medal,
                value: data.stats.totalPrize._sum?.totalPrize || 0,
                label: "Призовых (₽)",
                format: true,
              },
            ].map((stat) => (
              <div key={stat.label} className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-dynamo-100 dark:bg-dynamo-900/50">
                  <stat.icon className="h-5 w-5 text-dynamo-600 dark:text-dynamo-400" />
                </div>
                <div>
                  <p className="text-lg font-bold leading-none">
                    {stat.format
                      ? stat.value.toLocaleString("ru-RU")
                      : stat.value}
                  </p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Upcoming tournaments */}
      <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Ближайшие турниры</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Не пропустите главные события сезона
            </p>
          </div>
          <Link href="/tournaments">
            <Button variant="outline" size="sm">
              Все турниры <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>

        {data.upcomingTournaments.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {data.upcomingTournaments.map((t) => (
              <TournamentCard key={t.id} tournament={t} />
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <Trophy className="mx-auto h-12 w-12 text-muted-foreground/40" />
            <p className="mt-4 text-muted-foreground">
              Пока нет запланированных турниров
            </p>
            <Link href="/tournaments" className="mt-2 inline-block text-sm text-dynamo-600 hover:underline">
              Перейти к архиву турниров
            </Link>
          </Card>
        )}
      </section>

      {/* News + Leaderboard */}
      <section className="border-t border-border/40 bg-muted/20">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-3">
            {/* News */}
            <div className="lg:col-span-2">
              <div className="mb-6 flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight">Последние новости</h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Актуальные события из жизни клуба
                  </p>
                </div>
                <Link href="/news">
                  <Button variant="outline" size="sm">
                    Все новости <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </div>

              {data.latestNews.length > 0 ? (
                <div className="grid gap-6 sm:grid-cols-2">
                  {data.latestNews.map((n) => (
                    <NewsCard key={n.id} news={n} />
                  ))}
                </div>
              ) : (
                <Card className="p-8 text-center">
                  <Newspaper className="mx-auto h-10 w-10 text-muted-foreground/40" />
                  <p className="mt-3 text-muted-foreground">Новости скоро появятся</p>
                </Card>
              )}
            </div>

            {/* Leaderboard */}
            <div>
              <Leaderboard players={data.topPlayers} />
            </div>
          </div>
        </div>
      </section>

      {/* Latest Winners */}
      {data.latestWinners.length > 0 && (
        <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <h2 className="mb-8 text-2xl font-bold tracking-tight">Последние победители</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            {data.latestWinners.map((player, idx) => (
              <Card key={player.id} className="flex items-center gap-4 p-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-amber-500/10">
                  <Medal className="h-6 w-6 text-amber-500" />
                </div>
                <div className="min-w-0">
                  <Link
                    href={`/players/${player.id}`}
                    className="truncate font-medium hover:text-dynamo-600"
                  >
                    {player.nickname}
                  </Link>
                  <p className="text-xs text-muted-foreground">
                    {player.wins} побед • Рейтинг {player.rating}
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="border-t border-border/40 bg-dynamo-950 py-16">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white">Присоединяйтесь к сообществу</h2>
          <p className="mx-auto mt-3 max-w-xl text-dynamo-200">
            Участвуйте в турнирах, отслеживайте свою статистику и становитесь лучше вместе с Динамо Королёв
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/register">
              <Button className="bg-white text-dynamo-900 hover:bg-dynamo-100">
                <Users className="mr-2 h-4 w-4" />
                Зарегистрироваться
              </Button>
            </Link>
            <Button
              variant="outline"
              className="border-dynamo-400/30 text-white hover:bg-dynamo-800"
            >
              <MessageCircle className="mr-2 h-4 w-4" />
              Telegram
            </Button>
          </div>
        </div>
      </section>

      {/* Partners */}
      <PartnerLogos />
    </div>
  );
}
