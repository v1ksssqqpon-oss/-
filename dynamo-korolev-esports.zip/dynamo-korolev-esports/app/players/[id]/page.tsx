import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar";
import { Separator } from "@/components/ui/Separator";
import {
  Trophy,
  TrendingUp,
  TrendingDown,
  Swords,
  Calendar,
  MapPin,
  Star,
  Award,
  ChevronLeft,
  Zap,
  Medal,
} from "lucide-react";
import Link from "next/link";

async function getPlayer(id: string) {
  const player = await prisma.player.findUnique({
    where: { id },
    include: {
      achievements: { include: { achievement: true } },
      ratingHistory: { orderBy: { createdAt: "desc" }, take: 20 },
      matchResults: {
        include: { match: { include: { tournament: true } } },
        orderBy: { createdAt: "desc" },
        take: 10,
      },
    },
  });
  return player;
}

export default async function PlayerPage({
  params,
}: {
  params: { id: string };
}) {
  const player = await getPlayer(params.id);
  if (!player) notFound();

  const winRate =
    player.wins + player.losses > 0
      ? Math.round((player.wins / (player.wins + player.losses)) * 100)
      : 0;

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <Link
        href="/players"
        className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" />
        Все игроки
      </Link>

      {/* Profile header */}
      <div className="mb-8 flex flex-col gap-6 sm:flex-row sm:items-start">
        <Avatar className="h-24 w-24 sm:h-32 sm:w-32 ring-4 ring-dynamo-100 dark:ring-dynamo-900">
          <AvatarImage src={player.avatar || undefined} />
          <AvatarFallback className="bg-dynamo-100 text-dynamo-700 text-2xl font-bold">
            {player.nickname.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-3xl font-bold tracking-tight">{player.nickname}</h1>
            <Badge className="bg-dynamo-600">LVL {player.level}</Badge>
          </div>
          {player.realName && (
            <p className="mt-1 text-muted-foreground">{player.realName}</p>
          )}
          <div className="mt-3 flex flex-wrap gap-3 text-sm text-muted-foreground">
            {player.city && (
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5" />
                {player.city}
              </span>
            )}
            {player.age && (
              <span className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                {player.age} лет
              </span>
            )}
            <span className="flex items-center gap-1">
              <Zap className="h-3.5 w-3.5" />
              {player.experience} XP
            </span>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            <Badge variant="secondary">
              <Trophy className="mr-1 h-3 w-3" />
              {player.rating} ELO
            </Badge>
            <Badge variant="outline">{winRate}% WR</Badge>
            <Badge variant="outline">{player.winStreak} серия</Badge>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Stats */}
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              { label: "Победы", value: player.wins, icon: TrendingUp, color: "text-emerald-500" },
              { label: "Поражения", value: player.losses, icon: TrendingDown, color: "text-red-500" },
              { label: "Турниров", value: player.tournamentsPlayed, icon: Trophy, color: "text-amber-500" },
              { label: "Призовых", value: `${player.totalPrize.toLocaleString("ru-RU")} ₽`, icon: Medal, color: "text-dynamo-500" },
            ].map((stat) => (
              <Card key={stat.label} className="p-4 text-center">
                <stat.icon className={`mx-auto h-5 w-5 ${stat.color}`} />
                <p className="mt-2 text-xl font-bold">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </Card>
            ))}
          </div>

          {/* Recent matches */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Swords className="h-4 w-4" />
                Последние матчи
              </CardTitle>
            </CardHeader>
            <CardContent>
              {player.matchResults.length > 0 ? (
                <div className="space-y-2">
                  {player.matchResults.map((result) => (
                    <div
                      key={result.id}
                      className="flex items-center justify-between rounded-lg border border-border p-3"
                    >
                      <div>
                        <p className="text-sm font-medium">
                          {result.match.tournament?.name || "Турнир"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Раунд {result.match.round}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-bold">{result.score}</span>
                        <Badge
                          variant={result.winner ? "success" : "destructive"}
                          className="text-xs"
                        >
                          {result.winner ? "Победа" : "Поражение"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Пока нет матчей</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Award className="h-4 w-4 text-amber-500" />
                Достижения
              </CardTitle>
            </CardHeader>
            <CardContent>
              {player.achievements.length > 0 ? (
                <div className="space-y-2">
                  {player.achievements.map((pa) => (
                    <div
                      key={pa.id}
                      className="flex items-center gap-2 rounded-md bg-accent/50 p-2"
                    >
                      <Star className="h-4 w-4 text-amber-500" />
                      <div>
                        <p className="text-sm font-medium">{pa.achievement.name}</p>
                        <p className="text-[10px] text-muted-foreground">
                          {new Date(pa.earnedAt).toLocaleDateString("ru-RU")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Пока нет достижений</p>
              )}
            </CardContent>
          </Card>

          {/* Rating history */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">История рейтинга</CardTitle>
            </CardHeader>
            <CardContent>
              {player.ratingHistory.length > 0 ? (
                <div className="space-y-1.5">
                  {player.ratingHistory.slice(0, 10).map((rh) => (
                    <div
                      key={rh.id}
                      className="flex items-center justify-between text-sm"
                    >
                      <span className="text-muted-foreground">
                        {new Date(rh.createdAt).toLocaleDateString("ru-RU")}
                      </span>
                      <span className="flex items-center gap-1">
                        {rh.rating}
                        <span
                          className={
                            rh.change > 0
                              ? "text-emerald-500"
                              : rh.change < 0
                              ? "text-red-500"
                              : "text-muted-foreground"
                          }
                        >
                          {rh.change > 0 ? "+" : ""}
                          {rh.change}
                        </span>
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">История пуста</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
