import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/Card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { Input } from "@/components/ui/Input";
import { Users, Search, Trophy, TrendingUp } from "lucide-react";
import Link from "next/link";

async function getPlayers() {
  return prisma.player.findMany({
    orderBy: { rating: "desc" },
  });
}

export default async function PlayersPage() {
  const players = await getPlayers();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Игроки</h1>
        <p className="mt-2 text-muted-foreground">
          Список всех игроков сообщества
        </p>
      </div>

      {/* Search placeholder */}
      <div className="mb-6 relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Поиск по нику..."
          className="pl-9"
          disabled
        />
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
          Поиск будет доступен после подключения базы данных
        </span>
      </div>

      {players.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {players.map((player, idx) => {
            const winRate =
              player.wins + player.losses > 0
                ? Math.round((player.wins / (player.wins + player.losses)) * 100)
                : 0;

            return (
              <Link key={player.id} href={`/players/${player.id}`}>
                <Card className="group cursor-pointer p-4 transition-all hover:border-dynamo-500/50 hover:shadow-md">
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Avatar className="h-14 w-14">
                        <AvatarImage src={player.avatar || undefined} />
                        <AvatarFallback className="bg-dynamo-100 text-dynamo-700 text-sm font-bold">
                          {player.nickname.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-dynamo-600 text-[9px] font-bold text-white">
                        {player.level}
                      </span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate font-semibold group-hover:text-dynamo-600 transition-colors">
                        {player.nickname}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {player.realName || "Игрок"}
                      </p>
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        <Badge variant="secondary" className="text-[10px]">
                          <TrendingUp className="mr-0.5 h-2.5 w-2.5" />
                          {player.rating} ELO
                        </Badge>
                        <Badge variant="outline" className="text-[10px]">
                          {winRate}% WR
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border/50 pt-3 text-center">
                    <div>
                      <p className="text-sm font-bold">{player.wins}</p>
                      <p className="text-[10px] text-muted-foreground">Побед</p>
                    </div>
                    <div>
                      <p className="text-sm font-bold">{player.losses}</p>
                      <p className="text-[10px] text-muted-foreground">Поражений</p>
                    </div>
                    <div>
                      <p className="text-sm font-bold">{player.tournamentsPlayed}</p>
                      <p className="text-[10px] text-muted-foreground">Турниров</p>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      ) : (
        <Card className="p-12 text-center">
          <Users className="mx-auto h-12 w-12 text-muted-foreground/40" />
          <p className="mt-4 text-muted-foreground">Пока нет зарегистрированных игроков</p>
        </Card>
      )}
    </div>
  );
}
