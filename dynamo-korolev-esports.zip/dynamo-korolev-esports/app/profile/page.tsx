import { getServerSession } from "next-auth/next";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Separator } from "@/components/ui/Separator";
import { Trophy, Swords, Award, Settings } from "lucide-react";
import Link from "next/link";

export default async function ProfilePage() {
  const session = await getServerSession();
  if (!session?.user?.email) redirect("/login");

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
    include: { player: { include: { achievements: { include: { achievement: true } } } } },
  });
  if (!user?.player) redirect("/");

  const p = user.player;
  const winRate = p.wins + p.losses > 0 ? Math.round((p.wins / (p.wins + p.losses)) * 100) : 0;

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
        <Avatar className="h-24 w-24 ring-4 ring-dynamo-100 dark:ring-dynamo-900">
          <AvatarImage src={p.avatar || undefined} />
          <AvatarFallback className="bg-dynamo-100 text-dynamo-700 text-2xl font-bold">{p.nickname.slice(0,2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-3xl font-bold">{p.nickname}</h1>
            <Badge className="bg-dynamo-600">LVL {p.level}</Badge>
          </div>
          <p className="text-muted-foreground">{user.email}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge variant="secondary"><Trophy className="mr-1 h-3 w-3"/>{p.rating} ELO</Badge>
            <Badge variant="outline">{winRate}% WR</Badge>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm"><Settings className="mr-1 h-4 w-4"/>Настройки</Button>
        </div>
      </div>

      <Separator className="my-8" />

      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { label: "Победы", value: p.wins, icon: Trophy },
          { label: "Поражения", value: p.losses, icon: Swords },
          { label: "Турниров", value: p.tournamentsPlayed, icon: Award },
          { label: "Призовых", value: `${p.totalPrize.toLocaleString("ru-RU")} ₽`, icon: Trophy },
        ].map((s) => (
          <Card key={s.label} className="p-4 text-center">
            <s.icon className="mx-auto h-5 w-5 text-dynamo-500" />
            <p className="mt-2 text-xl font-bold">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </Card>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="text-lg font-semibold mb-4">Достижения</h2>
        {p.achievements.length > 0 ? (
          <div className="grid gap-3 sm:grid-cols-2">
            {p.achievements.map((a) => (
              <Card key={a.id} className="p-3 flex items-center gap-3">
                <Award className="h-5 w-5 text-amber-500" />
                <span className="text-sm font-medium">{a.achievement.name}</span>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-6 text-center text-sm text-muted-foreground">Пока нет достижений</Card>
        )}
      </div>
    </div>
  );
}
