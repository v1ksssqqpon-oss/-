import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { BarChart3, Trophy, TrendingUp, Medal } from "lucide-react";
import Link from "next/link";

async function getLeaderboards() {
  const byRating = await prisma.player.findMany({ orderBy: { rating: "desc" }, take: 20 });
  const byWins = await prisma.player.findMany({ orderBy: { wins: "desc" }, take: 20 });
  const byTournaments = await prisma.player.findMany({ orderBy: { tournamentsPlayed: "desc" }, take: 20 });
  const byPrize = await prisma.player.findMany({ orderBy: { totalPrize: "desc" }, take: 20 });
  return { byRating, byWins, byTournaments, byPrize };
}

function LeaderboardTable({ players, valueKey }: { players: any[]; valueKey: string }) {
  return (
    <div className="space-y-1">
      {players.map((p, i) => (
        <Link key={p.id} href={`/players/${p.id}`}>
          <div className="flex items-center gap-3 rounded-md p-2 hover:bg-accent/50 transition-colors">
            <span className="w-6 text-center text-sm font-bold text-muted-foreground">{i + 1}</span>
            <Avatar className="h-7 w-7">
              <AvatarImage src={p.avatar || undefined} />
              <AvatarFallback className="text-[10px] bg-dynamo-100 text-dynamo-700">{p.nickname.slice(0,2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <span className="flex-1 text-sm font-medium truncate">{p.nickname}</span>
            <Badge variant="secondary" className="text-xs">{p[valueKey]}</Badge>
          </div>
        </Link>
      ))}
    </div>
  );
}

export default async function RatingsPage() {
  const { byRating, byWins, byTournaments, byPrize } = await getLeaderboards();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold tracking-tight">Рейтинги</h1>
      <p className="mt-2 text-muted-foreground">Таблицы лидеров по разным категориям</p>
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Trophy className="h-4 w-4 text-amber-500"/> По рейтингу ELO</CardTitle></CardHeader>
          <CardContent><LeaderboardTable players={byRating} valueKey="rating"/></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-emerald-500"/> По победам</CardTitle></CardHeader>
          <CardContent><LeaderboardTable players={byWins} valueKey="wins"/></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><BarChart3 className="h-4 w-4 text-dynamo-500"/> По турнирам</CardTitle></CardHeader>
          <CardContent><LeaderboardTable players={byTournaments} valueKey="tournamentsPlayed"/></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Medal className="h-4 w-4 text-dynamo-500"/> По призовым</CardTitle></CardHeader>
          <CardContent><LeaderboardTable players={byPrize} valueKey="totalPrize"/></CardContent>
        </Card>
      </div>
    </div>
  );
}
