import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Calendar, Clock, Trophy } from "lucide-react";

export default async function SchedulePage() {
  const tournaments = await prisma.tournament.findMany({
    where: { status: { in: ["UPCOMING", "REGISTRATION_OPEN", "LIVE"] } },
    orderBy: { date: "asc" },
  });

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold tracking-tight">Расписание</h1>
      <p className="mt-2 text-muted-foreground">Календарь мероприятий</p>
      <div className="mt-8 space-y-4">
        {tournaments.length > 0 ? (
          tournaments.map((t) => (
            <Card key={t.id} className="flex items-center gap-4 p-4">
              <div className="flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-lg bg-dynamo-100 dark:bg-dynamo-900/50">
                <span className="text-xs font-bold uppercase text-dynamo-600 dark:text-dynamo-400">
                  {new Date(t.date).toLocaleDateString("ru-RU", { month: "short" })}
                </span>
                <span className="text-lg font-bold leading-none">
                  {new Date(t.date).getDate()}
                </span>
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">{t.name}</h3>
                <div className="mt-1 flex flex-wrap gap-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Trophy className="h-3 w-3"/>{t.discipline}</span>
                  {t.time && <span className="flex items-center gap-1"><Clock className="h-3 w-3"/>{t.time}</span>}
                </div>
              </div>
              <Badge variant={t.status === "LIVE" ? "destructive" : "secondary"}>
                {t.status === "REGISTRATION_OPEN" ? "Регистрация" : t.status === "LIVE" ? "LIVE" : "Скоро"}
              </Badge>
            </Card>
          ))
        ) : (
          <Card className="p-8 text-center text-muted-foreground">Нет запланированных мероприятий</Card>
        )}
      </div>
    </div>
  );
}
