import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar";
import { Separator } from "@/components/ui/Separator";
import {
  Trophy,
  Calendar,
  MapPin,
  Users,
  Medal,
  Clock,
  Swords,
  ChevronLeft,
  Share2,
  QrCode,
} from "lucide-react";
import Link from "next/link";

async function getTournament(slug: string) {
  const tournament = await prisma.tournament.findUnique({
    where: { slug },
    include: {
      registrations: {
        include: { player: true },
      },
      matches: {
        include: { results: true },
        orderBy: { round: "asc" },
      },
      _count: { select: { registrations: true } },
    },
  });
  return tournament;
}

const statusMap: Record<string, { label: string; variant: any }> = {
  UPCOMING: { label: "Скоро", variant: "secondary" },
  REGISTRATION_OPEN: { label: "Регистрация открыта", variant: "success" },
  REGISTRATION_CLOSED: { label: "Регистрация закрыта", variant: "warning" },
  LIVE: { label: "LIVE", variant: "destructive" },
  IN_PROGRESS: { label: "Идёт", variant: "warning" },
  COMPLETED: { label: "Завершён", variant: "outline" },
  CANCELLED: { label: "Отменён", variant: "destructive" },
};

export default async function TournamentPage({
  params,
}: {
  params: { slug: string };
}) {
  const tournament = await getTournament(params.slug);
  if (!tournament) notFound();

  const status = statusMap[tournament.status] || statusMap.UPCOMING;
  const participants = tournament._count.registrations;

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      {/* Breadcrumb */}
      <Link
        href="/tournaments"
        className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" />
        Все турниры
      </Link>

      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-wrap items-start gap-3">
          <Badge variant={status.variant}>{status.label}</Badge>
          <Badge variant="secondary">{tournament.discipline}</Badge>
          <Badge variant="outline">{tournament.format.replace(/_/g, " ")}</Badge>
        </div>
        <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">
          {tournament.name}
        </h1>
        <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Calendar className="h-4 w-4" />
            {new Date(tournament.date).toLocaleDateString("ru-RU", {
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
            {tournament.time && ` в ${tournament.time}`}
          </span>
          {tournament.location && (
            <span className="flex items-center gap-1.5">
              <MapPin className="h-4 w-4" />
              {tournament.location}
            </span>
          )}
          <span className="flex items-center gap-1.5">
            <Users className="h-4 w-4" />
            {participants} / {tournament.maxParticipants} участников
          </span>
          {tournament.prizePool > 0 && (
            <span className="flex items-center gap-1.5">
              <Medal className="h-4 w-4 text-amber-500" />
              {tournament.prizePool.toLocaleString("ru-RU")} ₽
            </span>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="mb-8 flex flex-wrap gap-3">
        {tournament.registrationOpen && (
          <Button className="bg-dynamo-600 hover:bg-dynamo-700">
            <Swords className="mr-2 h-4 w-4" />
            Зарегистрироваться
          </Button>
        )}
        <Button variant="outline">
          <QrCode className="mr-2 h-4 w-4" />
          QR-регистрация
        </Button>
        <Button variant="outline" size="icon">
          <Share2 className="h-4 w-4" />
        </Button>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Description */}
          {tournament.description && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Описание</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
                  {tournament.description}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Rules */}
          {tournament.rules && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Правила</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
                  {tournament.rules}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Matches */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Матчи</CardTitle>
            </CardHeader>
            <CardContent>
              {tournament.matches.length > 0 ? (
                <div className="space-y-2">
                  {tournament.matches.map((match) => (
                    <div
                      key={match.id}
                      className="flex items-center justify-between rounded-lg border border-border p-3"
                    >
                      <span className="text-xs text-muted-foreground">
                        Раунд {match.round}
                      </span>
                      <span className="text-sm font-medium">
                        {match.score1 ?? "-"} : {match.score2 ?? "-"}
                      </span>
                      <Badge
                        variant={
                          match.status === "COMPLETED"
                            ? "outline"
                            : match.status === "LIVE"
                            ? "destructive"
                            : "secondary"
                        }
                        className="text-xs"
                      >
                        {match.status === "SCHEDULED" && "Запланирован"}
                        {match.status === "LIVE" && "LIVE"}
                        {match.status === "COMPLETED" && "Завершён"}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Сетка турнира будет опубликована после закрытия регистрации
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Participants */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="h-4 w-4" />
                Участники ({participants})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {tournament.registrations.length > 0 ? (
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {tournament.registrations.map((reg) => (
                    <div
                      key={reg.id}
                      className="flex items-center gap-2 rounded-md p-2 hover:bg-accent/50"
                    >
                      <Avatar className="h-7 w-7">
                        <AvatarImage src={reg.player.avatar || undefined} />
                        <AvatarFallback className="text-[10px] bg-dynamo-100 text-dynamo-700">
                          {reg.player.nickname.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{reg.player.nickname}</span>
                      {reg.checkedIn && (
                        <Badge variant="success" className="ml-auto text-[10px]">
                          ✓
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Пока нет зарегистрированных участников
                </p>
              )}
            </CardContent>
          </Card>

          {/* Prize distribution placeholder */}
          {tournament.prizePool > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Medal className="h-4 w-4 text-amber-500" />
                  Призовой фонд
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">
                  {tournament.prizePool.toLocaleString("ru-RU")} ₽
                </p>
                <div className="mt-3 space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">1 место</span>
                    <span className="font-medium">
                      {Math.round(tournament.prizePool * 0.5).toLocaleString("ru-RU")} ₽
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">2 место</span>
                    <span className="font-medium">
                      {Math.round(tournament.prizePool * 0.3).toLocaleString("ru-RU")} ₽
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">3 место</span>
                    <span className="font-medium">
                      {Math.round(tournament.prizePool * 0.2).toLocaleString("ru-RU")} ₽
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
