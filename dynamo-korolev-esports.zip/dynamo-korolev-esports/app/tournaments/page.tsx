import { prisma } from "@/lib/prisma";
import { TournamentCard } from "@/components/home/TournamentCard";
import { Card } from "@/components/ui/Card";
import { Trophy, SlidersHorizontal } from "lucide-react";

async function getTournaments() {
  const tournaments = await prisma.tournament.findMany({
    orderBy: { date: "desc" },
    include: { _count: { select: { registrations: true } } },
  });
  return tournaments;
}

export default async function TournamentsPage() {
  const tournaments = await getTournaments();

  const upcoming = tournaments.filter((t) =>
    ["UPCOMING", "REGISTRATION_OPEN", "REGISTRATION_CLOSED"].includes(t.status)
  );
  const past = tournaments.filter((t) =>
    ["COMPLETED", "CANCELLED"].includes(t.status)
  );
  const live = tournaments.filter((t) =>
    ["LIVE", "IN_PROGRESS"].includes(t.status)
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Турниры</h1>
        <p className="mt-2 text-muted-foreground">
          Все турниры сообщества Динамо Королёв
        </p>
      </div>

      {/* Filters placeholder */}
      <div className="mb-6 flex flex-wrap gap-2">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium">
          <SlidersHorizontal className="h-3 w-3" />
          Все дисциплины
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium">
          Все форматы
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium">
          Все статусы
        </span>
      </div>

      {/* Live */}
      {live.length > 0 && (
        <section className="mb-10">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-500" />
            </span>
            Сейчас идут
          </h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {live.map((t) => (
              <TournamentCard key={t.id} tournament={t} />
            ))}
          </div>
        </section>
      )}

      {/* Upcoming */}
      <section className="mb-10">
        <h2 className="mb-4 text-lg font-semibold">Предстоящие</h2>
        {upcoming.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {upcoming.map((t) => (
              <TournamentCard key={t.id} tournament={t} />
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center">
            <Trophy className="mx-auto h-10 w-10 text-muted-foreground/40" />
            <p className="mt-3 text-muted-foreground">Нет предстоящих турниров</p>
          </Card>
        )}
      </section>

      {/* Past */}
      {past.length > 0 && (
        <section>
          <h2 className="mb-4 text-lg font-semibold">Завершённые</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {past.map((t) => (
              <TournamentCard key={t.id} tournament={t} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
