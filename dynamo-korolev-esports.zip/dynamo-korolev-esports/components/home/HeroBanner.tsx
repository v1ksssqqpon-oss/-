"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Trophy, Calendar, MapPin, Users, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import Countdown from "react-countdown";

interface HeroBannerProps {
  tournament: {
    name: string;
    discipline: string;
    date: string;
    location?: string;
    maxParticipants: number;
    prizePool: number;
    slug: string;
  } | null;
}

const CountdownRenderer = ({
  days,
  hours,
  minutes,
  seconds,
}: {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}) => (
  <div className="flex gap-3">
    {[
      { value: days, label: "ДНЕЙ" },
      { value: hours, label: "ЧАСОВ" },
      { value: minutes, label: "МИНУТ" },
      { value: seconds, label: "СЕКУНД" },
    ].map((item) => (
      <div
        key={item.label}
        className="flex flex-col items-center rounded-lg bg-white/10 px-3 py-2 backdrop-blur-sm"
      >
        <span className="text-xl font-bold tabular-nums sm:text-2xl">
          {String(item.value).padStart(2, "0")}
        </span>
        <span className="text-[9px] font-medium tracking-wider text-white/70">
          {item.label}
        </span>
      </div>
    ))}
  </div>
);

export function HeroBanner({ tournament }: HeroBannerProps) {
  if (!tournament) {
    return (
      <section className="relative overflow-hidden bg-dynamo-950 py-24 sm:py-32">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-dynamo-800/30 via-dynamo-950 to-dynamo-950" />
        <div className="relative mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-extrabold tracking-tight text-white sm:text-6xl"
          >
            Динамо Королёв
          </motion.h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-dynamo-200">
            Киберспортивная платформа нового поколения
          </p>
        </div>
      </section>
    );
  }

  const tournamentDate = new Date(tournament.date);
  const isUpcoming = tournamentDate > new Date();

  return (
    <section className="relative overflow-hidden bg-dynamo-950 py-16 sm:py-24">
      {/* Background effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-dynamo-700/20 via-dynamo-950 to-dynamo-950" />
      <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-dynamo-600/10 blur-3xl" />
      <div className="absolute -bottom-20 -right-20 h-72 w-72 rounded-full bg-dynamo-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Left */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge
              variant="warning"
              className="mb-4 bg-amber-500/20 text-amber-300 border-amber-500/30"
            >
              <Trophy className="mr-1 h-3 w-3" />
              Ближайший турнир
            </Badge>

            <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-5xl">
              {tournament.name}
            </h1>

            <div className="mt-6 flex flex-wrap gap-4 text-sm text-dynamo-200">
              <span className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4 text-dynamo-400" />
                {new Date(tournament.date).toLocaleDateString("ru-RU", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </span>
              {tournament.location && (
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-dynamo-400" />
                  {tournament.location}
                </span>
              )}
              <span className="flex items-center gap-1.5">
                <Users className="h-4 w-4 text-dynamo-400" />
                до {tournament.maxParticipants} участников
              </span>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link href={`/tournaments/${tournament.slug}`}>
                <Button className="bg-white text-dynamo-900 hover:bg-dynamo-100">
                  Подробнее
                  <ArrowRight className="ml-1.5 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/tournaments">
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  Все турниры
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Right — Countdown */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col items-center lg:items-end"
          >
            {isUpcoming ? (
              <>
                <p className="mb-4 text-sm font-medium uppercase tracking-widest text-dynamo-300">
                  До начала турнира
                </p>
                <Countdown
                  date={tournamentDate}
                  renderer={CountdownRenderer}
                />
              </>
            ) : (
              <div className="rounded-xl bg-white/5 p-6 text-center backdrop-blur-sm">
                <p className="text-lg font-semibold text-white">Турнир уже идёт!</p>
                <p className="mt-1 text-sm text-dynamo-300">
                  Следите за результатами в разделе LIVE
                </p>
              </div>
            )}

            <div className="mt-6 rounded-xl bg-white/5 p-4 backdrop-blur-sm">
              <p className="text-xs uppercase tracking-wider text-dynamo-300">
                Призовой фонд
              </p>
              <p className="text-2xl font-bold text-white">
                {tournament.prizePool.toLocaleString("ru-RU")} ₽
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
