"use client";

import Link from "next/link";
import { Trophy, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/utils";

interface LeaderboardProps {
  players: {
    id: string;
    nickname: string;
    avatar?: string;
    rating: number;
    wins: number;
    losses: number;
    level: number;
  }[];
}

export function Leaderboard({ players }: LeaderboardProps) {
  const sorted = [...players].sort((a, b) => b.rating - a.rating).slice(0, 10);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <Trophy className="h-5 w-5 text-amber-500" />
            Топ игроков
          </CardTitle>
          <Link href="/ratings" className="text-xs text-dynamo-600 hover:underline">
            Все рейтинги →
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-border">
          {sorted.map((player, idx) => {
            const winRate =
              player.wins + player.losses > 0
                ? Math.round((player.wins / (player.wins + player.losses)) * 100)
                : 0;

            return (
              <div
                key={player.id}
                className="flex items-center gap-3 px-6 py-3 transition-colors hover:bg-accent/50"
              >
                <span
                  className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold",
                    idx === 0 && "bg-amber-500/20 text-amber-600",
                    idx === 1 && "bg-slate-400/20 text-slate-500",
                    idx === 2 && "bg-orange-600/20 text-orange-700",
                    idx > 2 && "text-muted-foreground"
                  )}
                >
                  {idx + 1}
                </span>

                <Avatar className="h-8 w-8">
                  <AvatarImage src={player.avatar || undefined} />
                  <AvatarFallback className="bg-dynamo-100 text-dynamo-700 text-xs">
                    {player.nickname.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>

                <div className="min-w-0 flex-1">
                  <Link
                    href={`/players/${player.id}`}
                    className="truncate text-sm font-medium hover:text-dynamo-600"
                  >
                    {player.nickname}
                  </Link>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>LVL {player.level}</span>
                    <span>•</span>
                    <span>{winRate}% WR</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-sm font-bold text-dynamo-600">
                    {player.rating}
                  </span>
                  <span className="ml-1 text-[10px] text-muted-foreground">ELO</span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
