"use client";

import Link from "next/link";
import { Calendar, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

interface NewsCardProps {
  news: {
    id: string;
    title: string;
    slug: string;
    excerpt?: string;
    image?: string;
    category?: string;
    pinned: boolean;
    publishedAt?: string;
  };
  featured?: boolean;
}

export function NewsCard({ news, featured }: NewsCardProps) {
  return (
    <Link href={`/news/${news.slug}`}>
      <Card className="group cursor-pointer overflow-hidden transition-all hover:border-dynamo-500/50 hover:shadow-md">
        <div className="relative h-48 bg-gradient-to-br from-dynamo-900 to-slate-900">
          {news.image ? (
            <img
              src={news.image}
              alt={news.title}
              className="h-full w-full object-cover opacity-80 transition-opacity group-hover:opacity-100"
            />
          ) : (
            <div className="flex h-full items-center justify-center">
              <span className="text-4xl font-black text-dynamo-800/30">НОВОСТИ</span>
            </div>
          )}
          <div className="absolute left-4 top-4 flex gap-2">
            {news.pinned && (
              <Badge className="bg-dynamo-600 text-white">Закреплено</Badge>
            )}
            {news.category && (
              <Badge variant="secondary">{news.category}</Badge>
            )}
          </div>
        </div>
        <CardContent className="p-4">
          <h3 className="font-semibold leading-tight group-hover:text-dynamo-500 transition-colors line-clamp-2">
            {news.title}
          </h3>
          {news.excerpt && (
            <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
              {news.excerpt}
            </p>
          )}
          <div className="mt-3 flex items-center justify-between">
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              {news.publishedAt
                ? new Date(news.publishedAt).toLocaleDateString("ru-RU")
                : new Date().toLocaleDateString("ru-RU")}
            </span>
            <span className="flex items-center gap-1 text-xs font-medium text-dynamo-600 opacity-0 transition-opacity group-hover:opacity-100">
              Читать <ArrowRight className="h-3 w-3" />
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
