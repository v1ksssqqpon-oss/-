import { Zap } from "lucide-react";

export function PartnerLogos() {
  const partners = [
    "HyperPC", "Red Bull", "Logitech G", "NVIDIA", "Intel",
  ];

  return (
    <section className="border-y border-border/40 bg-muted/20 py-10">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="mb-6 text-center text-xs font-medium uppercase tracking-widest text-muted-foreground">
          Партнёры и спонсоры
        </p>
        <div className="flex flex-wrap items-center justify-center gap-8 opacity-50 grayscale transition-all hover:opacity-100 hover:grayscale-0">
          {partners.map((p) => (
            <div
              key={p}
              className="flex items-center gap-2 text-lg font-bold text-muted-foreground"
            >
              <Zap className="h-5 w-5" />
              {p}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
