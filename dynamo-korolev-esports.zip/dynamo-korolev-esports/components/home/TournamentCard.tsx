"use client";

import Link from "next/link";
import { Trophy, Calendar, Users, MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/utils";

interface TournamentCardProps {
  tournament: {
    id: string;
    name: string;
    slug: string;
    discipline: string;
    date: string;
    location?: string;
    maxParticipants: number;
    prizePool: number;
    status: string;
    registrationOpen: boolean;
    _count?: { registrations: number };
  };
  featured?: boolean;
}

const statusMap: Record<string, { label: string; variant: any }> = {
  UPCOMING: { label: "Скоро", variant: "secondary" },
  REGISTRATION_OPEN: { label: "Регистрация", variant: "success" },
  REGISTRATION_CLOSED: { label: "Регистрация закрыта", variant: "warning" },
  LIVE: { label: "LIVE", variant: "destructive" },
  IN_PROGRESS: { label: "Идёт", variant: "warning" },
  COMPLETED: { label: "Завершён", variant: "outline" },
  CANCELLED: { label: "Отменён", variant: "destructive" },
};

export function TournamentCard({ tournament, featured }: TournamentCardProps) {
  const status = statusMap[tournament.status] || statusMap.UPCOMING;
  const participants = tournament._count?.registrations ?? 0;

  return (
    <Link href={`/tournaments/${tournament.slug}`}>
      <Card
        className={cn(
          "group cursor-pointer overflow-hidden transition-all hover:border-dynamo-500/50 hover:shadow-lg hover:shadow-dynamo-500/10",
          featured && "border-dynamo-500/30"
        )}
      >
        <div className="relative h-40 bg-gradient-to-br from-dynamo-900 to-dynamo-950">
          <div className="absolute inset-0 flex items-center justify-center">
            <Trophy className="h-16 w-16 text-dynamo-700/40" />
          </div>
          <div className="absolute left-4 top-4">
            <Badge variant={status.variant}>{status.label}</Badge>
          </div>
          {featured && (
            <div className="absolute right-4 top-4">
              <Badge className="bg-amber-500 text-white">★ Featured</Badge>
            </div>
          )}
          <div className="absolute bottom-4 left-4">
            <span className="rounded-md bg-black/40 px-2 py-1 text-xs font-medium text-white backdrop-blur-sm">
              {tournament.discipline}
            </span>
          </div>
        </div>

        <CardContent className="p-4">
          <h3 className="font-semibold leading-tight group-hover:text-dynamo-500 transition-colors">
            {tournament.name}
          </h3>

          <div className="mt-3 space-y-1.5 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              {new Date(tournament.date).toLocaleDateString("ru-RU", {
                day: "numeric",
                month: "short",
              })}
            </div>
            {tournament.location && (
              <div className="flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5" />
                {tournament.location}
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              {participants} / {tournament.maxParticipants}
            </div>
          </div>

          {tournament.prizePool > 0 && (
            <div className="mt-3 rounded-md bg-dynamo-50 px-2.5 py-1.5 text-xs font-medium text-dynamo-700 dark:bg-dynamo-950/50 dark:text-dynamo-300">
              Призовой фонд: {tournament.prizePool.toLocaleString("ru-RU")} ₽
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
