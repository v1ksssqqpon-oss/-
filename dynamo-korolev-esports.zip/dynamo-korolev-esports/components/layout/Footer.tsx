import Link from "next/link";
import { Zap, Github, MessageCircle, Youtube, Twitch } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border/40 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-dynamo-600">
                <Zap className="h-4 w-4 text-white" />
              </div>
              <span className="text-sm font-bold">ДИНАМО КОРОЛЁВ</span>
            </Link>
            <p className="mt-3 text-sm text-muted-foreground">
              Профессиональная киберспортивная платформа для организации турниров,
              ведения статистики и развития сообщества.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-sm font-semibold">Платформа</h3>
            <ul className="mt-3 space-y-2">
              {["Турниры", "Игроки", "Рейтинги", "Новости", "Расписание"].map(
                (item) => (
                  <li key={item}>
                    <Link
                      href={`/${item.toLowerCase()}`}
                      className="text-sm text-muted-foreground hover:text-foreground"
                    >
                      {item}
                    </Link>
                  </li>
                )
              )}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold">Сообщество</h3>
            <ul className="mt-3 space-y-2">
              {["О клубе", "Зал славы", "Команда", "FAQ", "Обратная связь"].map(
                (item) => (
                  <li key={item}>
                    <span className="text-sm text-muted-foreground">{item}</span>
                  </li>
                )
              )}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold">Контакты</h3>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li>г. Королёв, Московская обл.</li>
              <li>esports@dynamokorolev.ru</li>
            </ul>
            <div className="mt-4 flex gap-3">
              <span className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-accent text-muted-foreground transition-colors hover:bg-dynamo-600 hover:text-white">
                <MessageCircle className="h-4 w-4" />
              </span>
              <span className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-accent text-muted-foreground transition-colors hover:bg-dynamo-600 hover:text-white">
                <Youtube className="h-4 w-4" />
              </span>
              <span className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-accent text-muted-foreground transition-colors hover:bg-dynamo-600 hover:text-white">
                <Twitch className="h-4 w-4" />
              </span>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-border/40 pt-8 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} Динамо Королёв. Все права защищены.
        </div>
      </div>
    </footer>
  );
}
