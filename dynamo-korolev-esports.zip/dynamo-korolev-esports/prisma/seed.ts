import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash("admin123", 12);
  const admin = await prisma.user.create({
    data: {
      name: "Администратор",
      email: "admin@dynamokorolev.ru",
      password: hashedPassword,
      role: "ADMIN",
    },
  });

  const achievements = [
    { name: "Первый турнир", description: "Примите участие в первом турнире", condition: "first_tournament" },
    { name: "Первая победа", description: "Выиграйте свой первый матч", condition: "first_win" },
    { name: "Чемпион", description: "Выиграйте турнир", condition: "champion" },
    { name: "MVP", description: "Получите звание MVP", condition: "mvp" },
    { name: "5 побед подряд", description: "Выиграйте 5 матчей подряд", condition: "win_streak_5" },
    { name: "10 побед подряд", description: "Выиграйте 10 матчей подряд", condition: "win_streak_10" },
    { name: "Легенда клуба", description: "Сыграйте 100 матчей", condition: "legend" },
  ];
  for (const a of achievements) {
    await prisma.achievement.create({ data: a });
  }

  const tournaments = [
    {
      name: "Dynamo Cup 2024",
      slug: "dynamo-cup-2024",
      discipline: "CS2",
      date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      time: "18:00",
      location: "Кибер-арена Динамо",
      maxParticipants: 32,
      prizePool: 50000,
      description: "Главный турнир сезона по Counter-Strike 2",
      rules: "Формат: Single Elimination, BO3 финал",
      format: "SINGLE_ELIMINATION",
      status: "REGISTRATION_OPEN",
      registrationOpen: true,
      featured: true,
    },
    {
      name: "Dota 2 Weekly #12",
      slug: "dota2-weekly-12",
      discipline: "Dota 2",
      date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      time: "19:00",
      location: "Онлайн",
      maxParticipants: 16,
      prizePool: 15000,
      description: "Еженедельный турнир по Dota 2",
      format: "DOUBLE_ELIMINATION",
      status: "UPCOMING",
      registrationOpen: true,
    },
    {
      name: "FIFA 24 Championship",
      slug: "fifa-24-championship",
      discipline: "EA FC 24",
      date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      time: "17:00",
      location: "Клубный дом",
      maxParticipants: 64,
      prizePool: 30000,
      description: "Чемпионат по EA FC 24",
      format: "SWISS",
      status: "COMPLETED",
      registrationOpen: false,
    },
  ];
  for (const t of tournaments) {
    await prisma.tournament.create({ data: t as any });
  }

  const playerUsers = [
    { name: "Иван Петров", email: "ivan@example.com", nickname: "Revenge", rating: 1850, wins: 45, losses: 12 },
    { name: "Алексей Смирнов", email: "alex@example.com", nickname: "Frost", rating: 1720, wins: 38, losses: 18 },
    { name: "Дмитрий Козлов", email: "dima@example.com", nickname: "Shadow", rating: 1680, wins: 30, losses: 20 },
    { name: "Максим Орлов", email: "max@example.com", nickname: "Phoenix", rating: 1950, wins: 52, losses: 8 },
    { name: "Артём Волков", email: "artem@example.com", nickname: "Vortex", rating: 1590, wins: 25, losses: 22 },
  ];

  for (const pu of playerUsers) {
    const hashed = await bcrypt.hash("password123", 12);
    const user = await prisma.user.create({
      data: { name: pu.name, email: pu.email, password: hashed },
    });
    await prisma.player.create({
      data: {
        userId: user.id,
        nickname: pu.nickname,
        realName: pu.name,
        city: "Королёв",
        rating: pu.rating,
        wins: pu.wins,
        losses: pu.losses,
        tournamentsPlayed: Math.floor((pu.wins + pu.losses) / 3),
        experience: (pu.wins + pu.losses) * 10,
        level: Math.floor(pu.rating / 200),
      },
    });
  }

  const news = [
    {
      title: "Открытие нового сезона Dynamo Esports",
      slug: "otkrytie-novogo-sezona",
      content: "Мы рады объявить о старте нового сезона киберспортивных турниров...",
      excerpt: "Новый сезон принесёт много интересных изменений",
      category: "Анонс",
      pinned: true,
      published: true,
      publishedAt: new Date(),
    },
    {
      title: "Результаты FIFA 24 Championship",
      slug: "rezultaty-fifa-24",
      content: "Турнир завершился яркой победой...",
      excerpt: "Лучшие моменты финального матча",
      category: "Результаты",
      published: true,
      publishedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    },
  ];
  for (const n of news) {
    await prisma.news.create({ data: n as any });
  }

  console.log("Seed completed!");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
