export interface Tournament {
  id: string;
  name: string;
  slug: string;
  discipline: string;
  date: string;
  time?: string;
  location?: string;
  maxParticipants: number;
  prizePool: number;
  description?: string;
  rules?: string;
  format: string;
  status: string;
  registrationOpen: boolean;
  checkInRequired: boolean;
  image?: string;
  featured: boolean;
  _count?: { registrations: number };
}

export interface Player {
  id: string;
  nickname: string;
  realName?: string;
  city?: string;
  age?: number;
  avatar?: string;
  rating: number;
  experience: number;
  level: number;
  wins: number;
  losses: number;
  tournamentsPlayed: number;
  totalPrize: number;
  winStreak: number;
  bestStreak: number;
}

export interface NewsItem {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  image?: string;
  category?: string;
  pinned: boolean;
  publishedAt?: string;
  createdAt: string;
}

export interface LeaderboardEntry {
  rank: number;
  player: Player;
  value: number;
}
